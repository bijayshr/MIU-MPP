package prob4C;

import java.time.LocalDate;
import java.util.List;

public class Main {

	public static void main(String[] args) {	    
	    
	    Commissioned commissioned = new Commissioned(2,10, 1000,List.of(new Order(123, LocalDate.of(2021, 1, 1), 1000, null)));
	    
	}

}
