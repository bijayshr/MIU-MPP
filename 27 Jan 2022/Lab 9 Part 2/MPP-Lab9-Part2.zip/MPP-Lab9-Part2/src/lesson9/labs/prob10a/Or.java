package lesson9.labs.prob10a;

import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Or {

	public static void main(String[] args) {

		// QUESTION 10_A
		List<Simple> list = Arrays.asList(new Simple(false), new Simple(false), new Simple(true));
		System.out.println(someSimpleIsTrue(list));

		// QUESTION 10_B
		Stream<String> stringStream = Stream.of("Bill", "Thomas", "Mary");
		System.out.println(collectingString(stringStream));

		// QUESTION 10_C
		Stream<Integer> myIntStream = Stream.of(3, 2, 1, 4, 5, 6, 7, 8, 9);
		System.out.println(findingMaxAndMinValue(myIntStream));

	}

	/**
	 * 
	 * GIVEN CODE SNIPPET
	 * 
	 * @param list
	 * @return boolean
	 */
//	public boolean someSimpleIsTrue(List<Simple> list) {
//		boolean accum = false;
//		for (Simple s : list) {
//			accum = accum || s.flag;
//		}
//		return accum;
//	}
	

	/**
	 * 
	 * ANSWER 10_A: Improved code snippet using reduce
	 * 
	 * @param list
	 * @return boolean
	 */
	public static boolean someSimpleIsTrue(List<Simple> list) {
		boolean accum = list.stream().map(l -> l.flag).reduce(false, (x, y) -> x || y);
//		System.out.println("TEST_A :: " + accum);
		return accum;
	}

	/**
	 * ANSWER 10_B: Using Collectors.joining
	 * 
	 * @param stringStream
	 * @return collectedString
	 */
	public static String collectingString(Stream<String> stringStream) {
		String collectedString = stringStream.collect(Collectors.joining(", "));
		System.out.println("TEST_B :: " + collectedString);
		return collectedString;
	}

	/**
	 * ANSWER 10_C: Using IntSummaryStatistics
	 * 
	 * @param myIntStream
	 * @return finalOutput
	 */
	public static String findingMaxAndMinValue(Stream<Integer> myIntStream) {
		IntSummaryStatistics summary = myIntStream.collect(Collectors.summarizingInt(i -> i));
		int max = summary.getMax();
		int min = summary.getMin();
		String finalOutput = "Max: " + max + " Min: " + min;
		return finalOutput;

	}

}
