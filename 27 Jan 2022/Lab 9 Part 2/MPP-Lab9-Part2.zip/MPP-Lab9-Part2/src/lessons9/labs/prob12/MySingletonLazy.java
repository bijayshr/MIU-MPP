package lessons9.labs.prob12;

import java.util.Optional;

public class MySingletonLazy {
	private static MySingletonLazy instance = null;

	private MySingletonLazy() {
	}

	/**
	 * Given MySingleton 'getInstance' method
	 * 
	 * @return instance
	 */
	/*
	public static MySingletonLazy getInstance() {
		if (instance == null) {
			instance = new MySingletonLazy();
		}
		return instance;
	}
	*/

	/**
	 * 
	 * Updated code snippet using 'ofNullable' from Optional
	 * 
	 * @return
	 */
	public static MySingletonLazy getInstance() {
		return Optional.ofNullable(instance).orElseGet(() -> new MySingletonLazy());
	}

	public static void main(String[] args) {
		MySingletonLazy obj1 = new MySingletonLazy();
		System.out.println("Hashcode for obj1: " + MySingletonLazy.getInstance().hashCode());

		MySingletonLazy obj2 = null;
		System.out.println("Hashcode for obj2: " + MySingletonLazy.getInstance().hashCode());
	}

}
