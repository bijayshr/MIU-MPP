package lessons9.labs.prob9;

import java.util.stream.IntStream;

public class PrintSquare {
	static int count = 1;

	public static void main(String[] args) {
		printSquare(4);
	}
	
	public static void printSquare(int num) {
		IntStream squareNumbers = IntStream.iterate(1, n-> calculateSquare(++count)).limit(num);
		/**
		 * Printing square numbers
		 */
		squareNumbers.forEach(sq->System.out.println(sq + " "));
	}
	
	public static int calculateSquare(int num) {
		return (int) Math.pow(num, 2);
	}

}
