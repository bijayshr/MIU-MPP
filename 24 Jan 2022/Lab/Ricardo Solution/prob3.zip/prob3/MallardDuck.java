package prob3;

public class MallardDuck extends Duck implements FlyWithWings, Quack {


}
