package prob3;

public interface FlyBehavior {
	public void fly();
}
