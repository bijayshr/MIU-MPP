package prob3;

import java.util.Arrays;

public class Main {
	public static void main(String[] args) {
		Duck[] ducks = 
			{
					new MallardDuck(), 
					new DecoyDuck(),
					new RedheadDuck(),
					new RobberDuck()
			};
		Arrays.stream(ducks).forEach(a -> {
			System.out.println("\n" + a.getClass().getSimpleName() + ":");
			a.display();
			a.fly();
			a.quack();
			a.swim();
		});
	}
}
