package prob3;

public interface QuackBehavior {
	public void quack();
}
