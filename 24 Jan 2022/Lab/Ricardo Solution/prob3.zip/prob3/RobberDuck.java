package prob3;

public class RobberDuck extends Duck implements CannotFly, Squeak{

}
