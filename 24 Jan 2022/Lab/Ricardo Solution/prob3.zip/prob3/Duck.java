package prob3;

/**
 * 
 * @author unsmoker
 *
 */
public abstract  class Duck implements QuackBehavior, FlyBehavior{
	public void swim() {
		System.out.println("swimming");
	};
	public void display() 
	{
		System.out.println("displaying");
	}
}