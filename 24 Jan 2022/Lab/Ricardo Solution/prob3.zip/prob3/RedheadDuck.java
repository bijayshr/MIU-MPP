package prob3;

public class RedheadDuck extends Duck implements FlyWithWings, Quack{

}
