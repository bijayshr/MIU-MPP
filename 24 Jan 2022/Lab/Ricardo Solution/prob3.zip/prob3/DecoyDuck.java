package prob3;

public class DecoyDuck extends Duck implements CannotFly, MuteQuack{

}
