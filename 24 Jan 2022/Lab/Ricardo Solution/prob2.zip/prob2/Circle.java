package prob2;


public class Circle implements ClosedCurve {
	//public because on class diagram is shown as public 
	private  double radius;
	
	public Circle(double radius) {
		this.radius = radius;
	}
	
	@Override
	public double computePerimeter() {
		return 2 * Math.PI * radius;
	}
}