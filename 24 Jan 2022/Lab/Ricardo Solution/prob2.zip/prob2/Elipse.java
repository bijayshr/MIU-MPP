package prob2;

public class Elipse implements ClosedCurve{
	
	public double semiaxis;
	public double elateral;
	
	Elipse(double axis, double elateral) {
		this.semiaxis = axis;
		this.elateral = elateral;
	}
	
	@Override
	public double computePerimeter() {
		return 4*this.semiaxis*this.elateral;
	}
}
