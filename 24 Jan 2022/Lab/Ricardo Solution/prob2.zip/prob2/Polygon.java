package prob2;

import java.util.Arrays;

public interface Polygon extends ClosedCurve{
	public double[] getLengths();
	
	default  double computePerimeter() {
		return Arrays.stream(getLengths()).reduce(0, Double::sum);
	}
	
}
