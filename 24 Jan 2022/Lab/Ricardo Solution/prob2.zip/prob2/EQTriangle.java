package prob2;

public class EQTriangle implements Polygon{
	public double side;
	EQTriangle(double side ){
		this.side = side;
	}
	@Override
	public double[] getLengths() {
		return new double[]{side, side, side};
	}
}
