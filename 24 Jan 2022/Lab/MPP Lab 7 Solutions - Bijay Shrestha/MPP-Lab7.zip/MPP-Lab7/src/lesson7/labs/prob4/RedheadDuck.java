package lesson7.labs.prob4;

public class RedheadDuck extends Duck {

	public RedheadDuck() {
		super();
	}
	
	@Override
	public void display() {
		System.out.println("Displaying - RedheadDuck");
	}

}

