Error:

The method equals from the class Object was not overridden.

Comparison is implemented with List.containts
List.contains evaluates using element1.equals(element2)