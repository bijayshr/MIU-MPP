package lesson7.labs.prob4;

public class MallardDuck extends Duck {

	public MallardDuck() {
		super();
	}

	@Override
	public void display() {
		System.out.println("Displaying - MallardDuck");
	}

}
