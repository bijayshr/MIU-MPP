Error:

The following code tracker.get(e).setVisited(true); was breaking the logic of the method removeDuplicates because it was changing the value visited in the object in the HashMap, and this value is used in equals method and hashCode.