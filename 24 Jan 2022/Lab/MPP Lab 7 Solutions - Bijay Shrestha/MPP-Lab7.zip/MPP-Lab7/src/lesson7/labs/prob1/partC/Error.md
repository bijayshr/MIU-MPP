Error:

Comparison is implemented with HashMap.contains
HashMap.containsKey evaluates using element1.hashcode.equals(element2.hashcode)

HashMap needs method hash code overridden from Object, and it was missing in the Employee class.