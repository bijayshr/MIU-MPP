package prob4;

public class Condo extends Property {
private int floors;
	
	public Condo(int floors) {
		this.floors = floors;
	}
	
	public int getFloors() {
		return floors;
	}
	public void setFloors(int floors) {
		this.floors = floors;
	}
	@Override
	public double rent() {
		return 500 * floors;
	}
}
