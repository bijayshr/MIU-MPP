package prob4;

public abstract class Property {

	public abstract double rent();
	
}
