package prob4;

public class Admin {
	
	public static double computeTotalRentAllProperties(Property[] properties) {
		double totalRent = 0;
		for (Property property : properties) {
			totalRent += property.rent();	
		}
		return totalRent;
	}
}
