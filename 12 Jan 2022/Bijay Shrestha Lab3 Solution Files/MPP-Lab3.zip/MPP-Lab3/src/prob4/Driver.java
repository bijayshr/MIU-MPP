package prob4;

public class Driver {

	public static void main(String[] args) {
		Property[] properties = { new House(9000), new Condo(2),
				new Trailer(new Address("Street", "city", "state", 222, null)) };
		double totalRent = Admin.computeTotalRentAllProperties(properties);
		System.out.println(totalRent);
	}

}
