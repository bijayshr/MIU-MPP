package prob3B;

public class Main {

	public static void main(String[] args) {
		
		Circle circle = new Circle(5);
		System.out.println("The area of the circle is: "+circle.computeArea());
		
	}
}
