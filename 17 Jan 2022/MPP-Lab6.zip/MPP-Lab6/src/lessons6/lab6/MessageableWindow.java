package lessons6.lab6;

public interface MessageableWindow
{
    default void displayError(final String msg) {
        BookClub.statusBar.setForeground(Util.ERROR_MESSAGE_COLOR);
        BookClub.statusBar.setText(msg);
    }
    
    default void displayInfo(final String msg) {
        BookClub.statusBar.setForeground(Util.INFO_MESSAGE_COLOR);
        BookClub.statusBar.setText(msg);
    }
    
    void updateData();
}
