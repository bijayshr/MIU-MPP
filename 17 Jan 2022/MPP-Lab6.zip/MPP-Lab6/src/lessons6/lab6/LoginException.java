package lessons6.lab6;

import java.io.Serializable;

public class LoginException extends Exception implements Serializable
{
    private static final long serialVersionUID = 8978723266036027364L;
    
    public LoginException() {
    }
    
    public LoginException(final String msg) {
        super(msg);
    }
    
    public LoginException(final Throwable t) {
        super(t);
    }
}
