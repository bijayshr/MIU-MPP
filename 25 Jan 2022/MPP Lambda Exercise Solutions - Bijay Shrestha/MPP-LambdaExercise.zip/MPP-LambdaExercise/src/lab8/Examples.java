package lab8;

import java.util.Comparator;
import java.util.function.BiConsumer;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.function.ToDoubleBiFunction;
import java.util.function.ToIntBiFunction;

public class Examples {

	Function<Employee, String> getEmpName = Employee::getName;

	BiConsumer<Employee, String> putEmployeeName = Employee::setName;

	ToIntBiFunction<String, String> compareString = String::compareTo;

	ToDoubleBiFunction<Integer, Integer> computeMathPow = Math::pow;

	Function<Apple, Double> getAppleWeight = Apple::getWeight;

	Function<String, Integer> parseInt = Integer::parseInt;

	Supplier<EmployeeNameComparator> employeeNameComparatorObj = EmployeeNameComparator::new;

	EmployeeNameComparator comp = new EmployeeNameComparator();
	ToIntBiFunction<Employee, Employee> compareTwoEmployee = comp::compare;

	void evaluator() {
		Employee emp1 = new Employee("Bijay");
		Employee emp2 = new Employee("Bishow");
		Apple apple = new Apple(1);

		System.out.println("1: " + getEmpName.apply(emp1));
		putEmployeeName.accept(emp1, "Suman Acharya");
		System.out.println("2: " + compareString.applyAsInt("Apple", "Banana"));
		System.out.println("3: " + computeMathPow.applyAsDouble(3, 5));
		System.out.println("4: " + getAppleWeight.apply(apple));
		System.out.println("5: " + parseInt.apply("32"));
		System.out.println("6: " + employeeNameComparatorObj.get().getClass().getSimpleName());
		System.out.println("7: " + compareTwoEmployee.applyAsInt(emp1, emp2));
	}

	public static void main(String[] args) {
		Examples examples = new Examples();
		examples.evaluator();
	}

}

class Employee {
	private String name;

	public String getName() {
		return name;
	}

	public Employee(String name) {
		this.name = name;
	}

	public void setName(String name) {
		this.name = name;
	}
}

class EmployeeNameComparator implements Comparator<Employee> {
	@Override
	public int compare(Employee e1, Employee e2) {
		return e1.getName().compareTo(e2.getName());
	}
}

class Apple {
	private double weight;

	public Apple(double weight) {
		this.weight = weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	public double getWeight() {
		return weight;
	}
}
