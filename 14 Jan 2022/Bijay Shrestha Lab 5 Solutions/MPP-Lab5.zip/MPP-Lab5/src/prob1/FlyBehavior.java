package prob1;

public interface FlyBehavior {
	void fly();
}
