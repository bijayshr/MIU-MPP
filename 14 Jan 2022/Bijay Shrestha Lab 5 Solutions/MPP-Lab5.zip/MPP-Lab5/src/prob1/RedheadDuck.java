package prob1;

public class RedheadDuck extends Duck {
	
    public RedheadDuck() {
        super(new FlyWithWings(), new Quack());
    }

    @Override
    void display() {
        System.out.println(" displaying");
    }
}

