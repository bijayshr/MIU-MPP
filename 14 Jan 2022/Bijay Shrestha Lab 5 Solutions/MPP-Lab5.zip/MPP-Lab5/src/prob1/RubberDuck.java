package prob1;

public class RubberDuck extends Duck{

    public RubberDuck() {
        super(new CannotFly(), new Squeak());
    }

    @Override
    void display() {
        System.out.println(" displaying");
    }
}