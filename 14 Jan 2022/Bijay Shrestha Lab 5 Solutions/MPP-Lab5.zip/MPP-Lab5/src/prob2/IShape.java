package prob2;

public interface IShape {
	public double computeArea();
}