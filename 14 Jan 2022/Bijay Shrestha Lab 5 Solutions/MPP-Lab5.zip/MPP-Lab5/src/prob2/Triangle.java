package prob2;

public final class Triangle implements IShape{

	private final double base, height;
	
	public Triangle(double base, double height) {
		super();
		this.base = base;
		this.height = height;
	}

	public double getBase() {
		return base;
	}
	public double getHeight() {
		return height;
	}
	@Override
	public double computeArea() {
		return height*(base/2);
	}

}