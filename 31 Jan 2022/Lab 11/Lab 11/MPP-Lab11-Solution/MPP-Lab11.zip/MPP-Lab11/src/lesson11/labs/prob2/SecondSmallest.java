package lesson11.labs.prob2;

import java.util.List;

public class SecondSmallest {

	public static void main(String[] args) {
		List<String> strings = List.of("A", "B", "C", "D", "E", "F", "G");
		List<Integer> integers = List.of(10, 20, 30, 40, 50, 60, 70, 80, 90);
		List<Double> doubles = List.of(1.1, 2.2, 3.3, 4.4, 5.5, 6.6, 7.7, 8.8);

		System.out.println(secondSmallest(strings));
		System.out.println(secondSmallest(integers));
		System.out.println(secondSmallest(doubles));
	}

	public static Object secondSmallest(List<?> list) {
		return secondSmallestHelper(list);
	}

	public static <T> T secondSmallestHelper(List<T> list) {
		return list.stream().sorted().skip(list.size() > 1 ? 1 : 0).findFirst().get();
	}

}
